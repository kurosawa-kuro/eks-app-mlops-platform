import { Hono } from 'hono';
// Initialize DI container (must be imported before routes)
import { resolve } from './container/index.js';
// Middleware
import { loginRateLimit } from './middleware/rateLimit.js';
import { health } from './routes/health.js';
import { auth } from './routes/auth.js';
const app = new Hono();
// Apply rate limiting to login endpoint (brute-force protection)
app.use('/auth/login', loginRateLimit);
app.get('/', (c) => {
    const env = resolve('env');
    return c.json({
        name: 'auth-service',
        description: 'Pluggable authentication service',
        provider: env.AUTH_PROVIDER,
        endpoints: {
            login: 'POST /auth/login',
            logout: 'POST /auth/logout',
            me: 'GET /auth/me',
            refresh: 'POST /auth/refresh',
            health: 'GET /health',
        },
    });
});
app.route('/health', health);
app.route('/auth', auth);
export default app;
