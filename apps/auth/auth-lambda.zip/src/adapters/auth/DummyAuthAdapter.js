import { BaseAuthAdapter } from './BaseAuthAdapter.js';
/**
 * Dummy authentication adapter for local development
 * Uses hard-coded credentials for testing
 */
export class DummyAuthAdapter extends BaseAuthAdapter {
    jwtService;
    tokenBlacklist;
    env;
    // Hard-coded dummy users for local development
    DUMMY_USERS = [
        {
            username: 'admin',
            password: 'password',
            id: 'dummy-admin-id',
            email: 'admin@example.com',
            role: 'admin',
        },
        {
            username: 'user',
            password: 'password',
            id: 'dummy-user-id',
            email: 'user@example.com',
            role: 'user',
        },
    ];
    constructor(jwtService, tokenBlacklist, env, logger) {
        super(logger);
        this.jwtService = jwtService;
        this.tokenBlacklist = tokenBlacklist;
        this.env = env;
        this.logger.info('DummyAuthAdapter initialized');
    }
    async login(credentials) {
        // Find user by username
        const user = this.DUMMY_USERS.find((u) => u.username === credentials.username && u.password === credentials.password);
        if (!user) {
            this.logger.debug({ username: credentials.username }, 'Login failed: invalid credentials');
            return this.failureResult('Invalid credentials');
        }
        // Generate tokens with role
        const tokenPayload = { sub: user.id, email: user.email, role: user.role };
        const [accessToken, refreshToken] = await Promise.all([
            this.jwtService.createToken(tokenPayload),
            this.jwtService.createRefreshToken(tokenPayload),
        ]);
        this.logger.info({ userId: user.id, role: user.role }, 'User logged in via DummyAdapter');
        return this.successResult({ id: user.id, email: user.email, role: user.role }, { accessToken, refreshToken, expiresIn: this.env.ACCESS_TOKEN_TTL });
    }
    async verify(token) {
        // Check blacklist first
        if (await this.tokenBlacklist.isBlacklisted(token)) {
            return { success: false, message: 'Token has been revoked' };
        }
        const payload = await this.jwtService.verifyToken(token);
        if (!payload) {
            return { success: false, message: 'Invalid or expired token' };
        }
        return { success: true, payload };
    }
    async refresh(refreshToken) {
        const payload = await this.jwtService.verifyRefreshToken(refreshToken);
        if (!payload) {
            return { success: false, message: 'Invalid or expired refresh token' };
        }
        const accessToken = await this.jwtService.createToken({
            sub: payload.sub,
            email: payload.email,
            role: payload.role,
        });
        return {
            success: true,
            accessToken,
            expiresIn: this.env.ACCESS_TOKEN_TTL,
        };
    }
    async logout(accessToken, _refreshToken) {
        // Add token to blacklist
        const expiresAt = new Date(Date.now() + this.env.ACCESS_TOKEN_TTL * 1000);
        await this.tokenBlacklist.add(accessToken, expiresAt);
        this.logger.debug('Token added to blacklist on logout');
        return { success: true };
    }
}
