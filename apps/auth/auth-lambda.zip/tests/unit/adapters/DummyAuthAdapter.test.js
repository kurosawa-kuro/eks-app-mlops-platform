import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { DummyAuthAdapter } from '../../../src/adapters/auth/DummyAuthAdapter.js';
import { JwtService } from '../../../src/services/JwtService.js';
import { InMemoryBlacklist } from '../../../src/adapters/blacklist/InMemoryBlacklist.js';
// Mock logger
const mockLogger = {
    debug: jest.fn(),
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
};
// Test environment config
const mockEnv = {
    JWT_SECRET: 'test-secret-key-for-adapter-testing',
    ACCESS_TOKEN_TTL: 3600,
    REFRESH_TOKEN_TTL: 604800,
};
describe('DummyAuthAdapter', () => {
    let adapter;
    let jwtService;
    let tokenBlacklist;
    beforeEach(() => {
        jest.clearAllMocks();
        jwtService = new JwtService(mockEnv, mockLogger);
        tokenBlacklist = new InMemoryBlacklist(mockLogger);
        adapter = new DummyAuthAdapter(jwtService, tokenBlacklist, mockEnv, mockLogger);
    });
    afterEach(() => {
        tokenBlacklist.destroy();
    });
    describe('login', () => {
        it('should return tokens for valid credentials', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const result = await adapter.login(credentials);
            expect(result.success).toBe(true);
            expect(result.accessToken).toBeDefined();
            expect(result.refreshToken).toBeDefined();
            expect(result.expiresIn).toBe(3600);
            expect(result.user?.id).toBe('dummy-admin-id');
            expect(result.user?.email).toBe('admin@example.com');
        });
        it('should log successful login', async () => {
            const credentials = { username: 'admin', password: 'password' };
            await adapter.login(credentials);
            expect(mockLogger.info).toHaveBeenCalledWith({ userId: 'dummy-admin-id', role: 'admin' }, 'User logged in via DummyAdapter');
        });
    });
    describe('verify', () => {
        it('should verify a valid access token', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const token = loginResult.accessToken;
            const result = await adapter.verify(token);
            expect(result.success).toBe(true);
            expect(result.payload?.sub).toBe('dummy-admin-id');
            expect(result.payload?.email).toBe('admin@example.com');
        });
        it('should reject blacklisted token', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const token = loginResult.accessToken;
            // Logout to blacklist the token
            await adapter.logout(token);
            const result = await adapter.verify(token);
            expect(result.success).toBe(false);
            expect(result.message).toBe('Token has been revoked');
        });
    });
    describe('refresh', () => {
        it('should return new access token for valid refresh token', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const refreshToken = loginResult.refreshToken;
            const result = await adapter.refresh(refreshToken);
            expect(result.success).toBe(true);
            expect(result.accessToken).toBeDefined();
            expect(result.expiresIn).toBe(3600);
        });
        it('should return valid access token on refresh', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const refreshToken = loginResult.refreshToken;
            const result = await adapter.refresh(refreshToken);
            expect(result.accessToken).toBeDefined();
            // Verify the new access token is valid
            const verifyResult = await adapter.verify(result.accessToken);
            expect(verifyResult.success).toBe(true);
        });
    });
    describe('logout', () => {
        it('should return success on logout', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const token = loginResult.accessToken;
            const result = await adapter.logout(token);
            expect(result.success).toBe(true);
        });
        it('should blacklist token on logout', async () => {
            const credentials = { username: 'admin', password: 'password' };
            const loginResult = await adapter.login(credentials);
            const token = loginResult.accessToken;
            await adapter.logout(token);
            const isBlacklisted = await tokenBlacklist.isBlacklisted(token);
            expect(isBlacklisted).toBe(true);
        });
    });
    describe('full auth flow', () => {
        it('should complete login -> verify -> refresh -> logout flow', async () => {
            // Login
            const loginResult = await adapter.login({ username: 'admin', password: 'password' });
            expect(loginResult.success).toBe(true);
            const accessToken = loginResult.accessToken;
            const refreshToken = loginResult.refreshToken;
            // Verify
            const verifyResult = await adapter.verify(accessToken);
            expect(verifyResult.success).toBe(true);
            // Refresh
            const refreshResult = await adapter.refresh(refreshToken);
            expect(refreshResult.success).toBe(true);
            const newAccessToken = refreshResult.accessToken;
            // Verify new token
            const verifyNewResult = await adapter.verify(newAccessToken);
            expect(verifyNewResult.success).toBe(true);
            // Logout
            const logoutResult = await adapter.logout(newAccessToken);
            expect(logoutResult.success).toBe(true);
            // Token should be blacklisted after logout
            const verifyAfterLogout = await adapter.verify(newAccessToken);
            expect(verifyAfterLogout.success).toBe(false);
        });
    });
});
